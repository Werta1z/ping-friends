package kz.avgar.guardping.cloud;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import kz.avgar.guardping.config.ModConfig;
import kz.avgar.guardping.model.AccountProfile;
import kz.avgar.guardping.model.PingMarker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

public class CloudSyncManager {
    private static final Gson GSON = new Gson();
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(6))
            .build();
    private static final ScheduledExecutorService EXECUTOR = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "GuardPing-CloudSync");
        t.setDaemon(true);
        return t;
    });

    public static final Map<String, AccountProfile> MOD_USERS = new ConcurrentHashMap<>();
    public static final List<PingMarker> ACTIVE_PINGS = new CopyOnWriteArrayList<>();
    public static final List<String> INCOMING_REQUESTS = new CopyOnWriteArrayList<>();

    public static volatile boolean isAuthenticated = false;
    public static volatile String authStatusMessage = "";
    public static volatile String latestToastText = "";
    public static volatile long latestToastUntil = 0L;

    private static boolean started = false;

    public static void start() {
        if (started) return;
        started = true;
        if (!ModConfig.INSTANCE.savedLogin.isBlank() && !ModConfig.INSTANCE.savedPasswordHash.isBlank() && isDbConfigured()) {
            EXECUTOR.submit(() -> authenticateWithHash(ModConfig.INSTANCE.savedLogin, ModConfig.INSTANCE.savedPasswordHash));
        }
        EXECUTOR.scheduleAtFixedRate(CloudSyncManager::syncCycle, 1000, 1200, TimeUnit.MILLISECONDS);
    }

    public static boolean isDbConfigured() {
        return ModConfig.INSTANCE.vercelApiUrl != null && !ModConfig.INSTANCE.vercelApiUrl.isBlank();
    }

    private static String getEndpoint() {
        String url = ModConfig.INSTANCE.vercelApiUrl.trim().replaceAll("/+$", "");
        if (!url.endsWith("/api/ping")) url += "/api/ping";
        return url;
    }

    private static HttpResponse<String> postAction(JsonObject payload) throws Exception {
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(getEndpoint()))
                .timeout(Duration.ofSeconds(6))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(payload), StandardCharsets.UTF_8))
                .build();
        return HTTP.send(req, HttpResponse.BodyHandlers.ofString());
    }

    private static void notifyChat(String msg) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null) {
            client.execute(() -> {
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("[Guard-Ping] " + msg), false);
                }
            });
        }
    }

    public static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(input.hashCode());
        }
    }

    public static void registerAsync(String login, String password, String confirmPassword, Runnable onDone) {
        if (!isDbConfigured()) {
            authStatusMessage = "§cВставь ссылку Vercel API в нижнее поле!";
            return;
        }
        if (login.isBlank() || password.isBlank()) {
            authStatusMessage = "§cВведи логин и пароль!";
            return;
        }
        if (!password.equals(confirmPassword)) {
            authStatusMessage = "§cПароли не совпадают!";
            return;
        }
        if (login.length() < 3) {
            authStatusMessage = "§cЛогин минимум 3 символа!";
            return;
        }
        authStatusMessage = "§eРегистрация...";
        String hash = sha256(password);

        EXECUTOR.submit(() -> {
            try {
                MinecraftClient client = MinecraftClient.getInstance();
                String mcNick = (client != null && client.player != null) ? client.player.getGameProfile().getName() : login;

                JsonObject payload = new JsonObject();
                payload.addProperty("action", "register");
                payload.addProperty("login", login);
                payload.addProperty("password_hash", hash);
                payload.addProperty("mc_nick", mcNick);

                HttpResponse<String> resp = postAction(payload);
                JsonObject resJson = JsonParser.parseString(resp.body()).getAsJsonObject();

                if (resp.statusCode() == 200 && resJson.has("ok") && resJson.get("ok").getAsBoolean()) {
                    ModConfig.INSTANCE.savedLogin = login;
                    ModConfig.INSTANCE.savedPasswordHash = hash;
                    ModConfig.INSTANCE.friends = new ArrayList<>();
                    ModConfig.save();
                    isAuthenticated = true;
                    authStatusMessage = "§aАккаунт создан!";
                    if (client != null && onDone != null) client.execute(onDone);
                } else {
                    String err = resJson.has("error") ? resJson.get("error").getAsString() : ("HTTP " + resp.statusCode());
                    authStatusMessage = "§c" + err;
                    notifyChat(authStatusMessage);
                }
            } catch (Throwable e) {
                authStatusMessage = "§cОшибка сети: " + e.getClass().getSimpleName();
                notifyChat(authStatusMessage + " (" + e.getMessage() + ")");
            }
        });
    }

    public static void loginAsync(String login, String password, Runnable onDone) {
        if (!isDbConfigured()) {
            authStatusMessage = "§cВставь ссылку Vercel API в нижнее поле!";
            return;
        }
        if (login.isBlank() || password.isBlank()) {
            authStatusMessage = "§cВведи логин и пароль!";
            return;
        }
        authStatusMessage = "§eВход...";
        String hash = sha256(password);
        EXECUTOR.submit(() -> {
            if (authenticateWithHash(login, hash)) {
                MinecraftClient client = MinecraftClient.getInstance();
                if (client != null && onDone != null) client.execute(onDone);
            }
        });
    }

    private static boolean authenticateWithHash(String login, String hash) {
        try {
            JsonObject payload = new JsonObject();
            payload.addProperty("action", "login");
            payload.addProperty("login", login);
            payload.addProperty("password_hash", hash);

            HttpResponse<String> resp = postAction(payload);
            JsonObject resJson = JsonParser.parseString(resp.body()).getAsJsonObject();

            if (resp.statusCode() == 200 && resJson.has("ok") && resJson.get("ok").getAsBoolean()) {
                ModConfig.INSTANCE.savedLogin = login;
                ModConfig.INSTANCE.savedPasswordHash = hash;
                List<String> loadedFriends = new ArrayList<>();
                if (resJson.has("friends") && resJson.get("friends").isJsonArray()) {
                    for (JsonElement f : resJson.get("friends").getAsJsonArray()) loadedFriends.add(f.getAsString());
                }
                ModConfig.INSTANCE.friends = loadedFriends;
                ModConfig.save();
                isAuthenticated = true;
                authStatusMessage = "§aВход выполнен!";
                return true;
            } else {
                String err = resJson.has("error") ? resJson.get("error").getAsString() : ("HTTP " + resp.statusCode());
                authStatusMessage = "§c" + err;
                notifyChat(authStatusMessage);
            }
        } catch (Throwable e) {
            authStatusMessage = "§cОшибка сети: " + e.getClass().getSimpleName();
            notifyChat(authStatusMessage + " (" + e.getMessage() + ")");
        }
        return false;
    }

    public static void logout() {
        isAuthenticated = false;
        ModConfig.INSTANCE.savedLogin = "";
        ModConfig.INSTANCE.savedPasswordHash = "";
        ModConfig.INSTANCE.friends.clear();
        ModConfig.save();
        INCOMING_REQUESTS.clear();
        ACTIVE_PINGS.clear();
        authStatusMessage = "§7Вы вышли из аккаунта";
    }

    private static void syncCycle() {
        try {
            if (!ModConfig.INSTANCE.modEnabled || !isAuthenticated || !isDbConfigured()) return;
            MinecraftClient client = MinecraftClient.getInstance();
            if (client == null || client.player == null || client.world == null) return;

            String myLogin = ModConfig.INSTANCE.savedLogin;
            String myMcNick = client.player.getGameProfile().getName();
            ACTIVE_PINGS.removeIf(p -> p.isExpired(ModConfig.INSTANCE.pingDurationSeconds));

            JsonObject payload = new JsonObject();
            payload.addProperty("action", "sync");
            payload.addProperty("login", myLogin);
            payload.addProperty("mc_nick", myMcNick);
            payload.addProperty("x", client.player.getX());
            payload.addProperty("y", client.player.getY());
            payload.addProperty("z", client.player.getZ());
            payload.addProperty("dimension", client.world.getRegistryKey().getValue().toString());
            payload.addProperty("pingDurationSeconds", ModConfig.INSTANCE.pingDurationSeconds);

            HttpResponse<String> resp = postAction(payload);
            if (resp.statusCode() != 200) return;

            JsonObject resJson = JsonParser.parseString(resp.body()).getAsJsonObject();
            List<String> myIncoming = new ArrayList<>();

            if (resJson.has("users") && resJson.get("users").isJsonArray()) {
                Set<String> seen = new HashSet<>();
                for (JsonElement el : resJson.get("users").getAsJsonArray()) {
                    JsonObject row = el.getAsJsonObject();
                    AccountProfile p = new AccountProfile();
                    p.login = row.get("login").getAsString();
                    p.mcNick = row.has("mc_nick") && !row.get("mc_nick").isJsonNull() ? row.get("mc_nick").getAsString() : p.login;
                    p.x = row.get("x").getAsDouble();
                    p.y = row.get("y").getAsDouble();
                    p.z = row.get("z").getAsDouble();
                    p.dimension = row.get("dimension").getAsString();
                    p.updatedAt = row.get("updated_at").getAsLong();
                    if (row.has("friends") && row.get("friends").isJsonArray()) {
                        for (JsonElement f : row.get("friends").getAsJsonArray()) p.friends.add(f.getAsString());
                    }
                    if (row.has("requests") && row.get("requests").isJsonArray()) {
                        for (JsonElement r : row.get("requests").getAsJsonArray()) p.requests.add(r.getAsString());
                    }
                    seen.add(p.login);
                    MOD_USERS.put(p.login, p);

                    if (p.login.equalsIgnoreCase(myLogin)) {
                        myIncoming.addAll(p.requests);
                        ModConfig.INSTANCE.friends = new ArrayList<>(p.friends);
                        ModConfig.save();
                    }
                }
                MOD_USERS.keySet().retainAll(seen);
            }

            for (String reqLogin : myIncoming) {
                if (!INCOMING_REQUESTS.contains(reqLogin)) {
                    latestToastText = "Заявка в друзья от " + reqLogin + " (нажми Page Up)";
                    latestToastUntil = System.currentTimeMillis() + 7000L;
                    client.execute(() -> {
                        if (client.player != null) {
                            client.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.3f);
                            client.player.sendMessage(Text.literal("[Guard-Ping] ").formatted(Formatting.AQUA)
                                    .append(Text.literal("Вам пришла заявка в друзья от " + reqLogin + "! Откройте меню (Page Up).").formatted(Formatting.YELLOW)), false);
                        }
                    });
                }
            }
            INCOMING_REQUESTS.clear();
            INCOMING_REQUESTS.addAll(myIncoming);

            if (resJson.has("pings") && resJson.get("pings").isJsonArray()) {
                List<PingMarker> fresh = new ArrayList<>();
                for (JsonElement el : resJson.get("pings").getAsJsonArray()) {
                    JsonObject row = el.getAsJsonObject();
                    PingMarker m = new PingMarker(
                            row.get("id").getAsString(),
                            row.get("sender").getAsString(),
                            row.get("x").getAsDouble(),
                            row.get("y").getAsDouble(),
                            row.get("z").getAsDouble(),
                            row.get("dimension").getAsString(),
                            row.get("created_at").getAsLong()
                    );
                    if (isFriendLoginOrSelf(m.sender)) fresh.add(m);
                }
                ACTIVE_PINGS.clear();
                ACTIVE_PINGS.addAll(fresh);
            }
        } catch (Exception ignored) {
        }
    }

    public static void publishPing(double x, double y, double z, String dimension) {
        if (!ModConfig.INSTANCE.modEnabled || !isAuthenticated) return;
        String sender = ModConfig.INSTANCE.savedLogin;
        String id = sender + "_" + System.currentTimeMillis();
        long now = System.currentTimeMillis();
        PingMarker marker = new PingMarker(id, sender, x, y, z, dimension, now);

        ACTIVE_PINGS.removeIf(p -> p.sender.equalsIgnoreCase(sender));
        ACTIVE_PINGS.add(marker);

        EXECUTOR.submit(() -> {
            try {
                JsonObject payload = new JsonObject();
                payload.addProperty("action", "ping");
                payload.addProperty("id", id);
                payload.addProperty("sender", sender);
                payload.addProperty("x", x);
                payload.addProperty("y", y);
                payload.addProperty("z", z);
                payload.addProperty("dimension", dimension);
                payload.addProperty("created_at", now);
                postAction(payload);
            } catch (Exception ignored) {
            }
        });
    }

    public static void sendFriendRequest(String targetLogin) {
        if (!isAuthenticated || targetLogin == null || targetLogin.isBlank()) return;
        String myLogin = ModConfig.INSTANCE.savedLogin;
        if (targetLogin.equalsIgnoreCase(myLogin)) return;
        notifyChat("§aЗаявка отправлена пользователю " + targetLogin);

        EXECUTOR.submit(() -> {
            try {
                JsonObject payload = new JsonObject();
                payload.addProperty("action", "request");
                payload.addProperty("from_login", myLogin);
                payload.addProperty("target_login", targetLogin);
                postAction(payload);
            } catch (Exception ignored) {
            }
        });
    }

    public static void acceptFriendRequest(String requesterLogin) {
        if (!ModConfig.INSTANCE.friends.contains(requesterLogin)) {
            ModConfig.INSTANCE.friends.add(requesterLogin);
            ModConfig.save();
        }
        INCOMING_REQUESTS.remove(requesterLogin);
        EXECUTOR.submit(() -> {
            try {
                JsonObject payload = new JsonObject();
                payload.addProperty("action", "accept");
                payload.addProperty("login", ModConfig.INSTANCE.savedLogin);
                payload.addProperty("requester_login", requesterLogin);
                postAction(payload);
            } catch (Exception ignored) {
            }
        });
    }

    public static void declineFriendRequest(String requesterLogin) {
        INCOMING_REQUESTS.remove(requesterLogin);
        EXECUTOR.submit(() -> {
            try {
                JsonObject payload = new JsonObject();
                payload.addProperty("action", "decline");
                payload.addProperty("login", ModConfig.INSTANCE.savedLogin);
                payload.addProperty("requester_login", requesterLogin);
                postAction(payload);
            } catch (Exception ignored) {
            }
        });
    }

    public static boolean isFriendLoginOrSelf(String login) {
        if (login == null) return false;
        if (login.equalsIgnoreCase(ModConfig.INSTANCE.savedLogin)) return true;
        return ModConfig.INSTANCE.friends.stream().anyMatch(f -> f.equalsIgnoreCase(login));
    }

    public static boolean isFriendByMcNick(String mcNick) {
        if (mcNick == null) return false;
        for (AccountProfile p : MOD_USERS.values()) {
            if (p.mcNick.equalsIgnoreCase(mcNick) && ModConfig.INSTANCE.friends.stream().anyMatch(f -> f.equalsIgnoreCase(p.login))) {
                return true;
            }
        }
        return false;
    }
}
