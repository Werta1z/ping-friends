package kz.avgar.guardping.mixin;

import kz.avgar.guardping.cloud.CloudSyncManager;
import kz.avgar.guardping.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.util.InputUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {

    @Shadow @Final public GameOptions options;

    @Inject(method = "doItemPick", at = @At("HEAD"), cancellable = true)
    private void guardping$cancelPickBlockOnPingKey(CallbackInfo ci) {
        if (!ModConfig.INSTANCE.modEnabled || !CloudSyncManager.isAuthenticated) return;
        InputUtil.Key expected = ModConfig.INSTANCE.pingKeyIsMouse
                ? InputUtil.Type.MOUSE.createFromCode(ModConfig.INSTANCE.pingKeyCode)
                : InputUtil.Type.KEYSYM.createFromCode(ModConfig.INSTANCE.pingKeyCode);
        if (this.options.pickItemKey.equals(expected)) {
            ci.cancel();
        }
    }
}
