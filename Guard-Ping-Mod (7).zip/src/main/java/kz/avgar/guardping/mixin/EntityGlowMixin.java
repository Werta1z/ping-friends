package kz.avgar.guardping.mixin;

import kz.avgar.guardping.cloud.CloudSyncManager;
import kz.avgar.guardping.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityGlowMixin {

    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void guardping$highlightVisibleFriends(CallbackInfoReturnable<Boolean> cir) {
        if (!ModConfig.INSTANCE.modEnabled || !ModConfig.INSTANCE.glowEnabled) return;
        Entity self = (Entity) (Object) this;
        if (!(self instanceof PlayerEntity target)) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || target == client.player) return;

        String mcNick = target.getGameProfile().getName();
        if (!CloudSyncManager.isFriendByMcNick(mcNick)) return;

        HitResult eyeCheck = client.world.raycast(new RaycastContext(
                client.player.getEyePos(),
                target.getEyePos(),
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                client.player
        ));
        HitResult bodyCheck = client.world.raycast(new RaycastContext(
                client.player.getEyePos(),
                target.getBoundingBox().getCenter(),
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                client.player
        ));

        if (eyeCheck.getType() == HitResult.Type.MISS || bodyCheck.getType() == HitResult.Type.MISS) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true)
    private void guardping$friendGlowColor(CallbackInfoReturnable<Integer> cir) {
        if (!ModConfig.INSTANCE.modEnabled || !ModConfig.INSTANCE.glowEnabled) return;
        Entity self = (Entity) (Object) this;
        if (self instanceof PlayerEntity player) {
            if (CloudSyncManager.isFriendByMcNick(player.getGameProfile().getName())) {
                cir.setReturnValue(ModConfig.INSTANCE.getAccentColor() & 0x00FFFFFF);
            }
        }
    }
}
