package kz.avgar.guardping.model;

public class PingMarker {
    public String id;
    public String sender;
    public double x;
    public double y;
    public double z;
    public String dimension;
    public long createdAt;

    public PingMarker() {}

    public PingMarker(String id, String sender, double x, double y, double z, String dimension, long createdAt) {
        this.id = id;
        this.sender = sender;
        this.x = x;
        this.y = y;
        this.z = z;
        this.dimension = dimension;
        this.createdAt = createdAt;
    }

    public boolean isExpired(int maxSeconds) {
        return (System.currentTimeMillis() - createdAt) > (maxSeconds * 1000L);
    }

    public float getProgress(int maxSeconds) {
        long elapsed = System.currentTimeMillis() - createdAt;
        return Math.max(0f, Math.min(1f, 1f - (elapsed / (maxSeconds * 1000f))));
    }
}
