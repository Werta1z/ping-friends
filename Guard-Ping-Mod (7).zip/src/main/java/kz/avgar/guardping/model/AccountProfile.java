package kz.avgar.guardping.model;

import java.util.ArrayList;
import java.util.List;

public class AccountProfile {
    public String login = "";
    public String mcNick = "";
    public double x;
    public double y;
    public double z;
    public String dimension = "minecraft:overworld";
    public List<String> friends = new ArrayList<>();
    public List<String> requests = new ArrayList<>();
    public long updatedAt;

    public boolean isOnline() {
        return (System.currentTimeMillis() - updatedAt) < 30_000L;
    }
}
