package kz.avgar.guardping.gui;

import kz.avgar.guardping.cloud.CloudSyncManager;
import kz.avgar.guardping.config.ModConfig;
import kz.avgar.guardping.model.AccountProfile;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Меню Guard-Ping-Mod (Page Up):
 * 1) Если не авторизован -> экран Входа / Регистрации (логин + пароль + повтор пароля).
 * 2) Если авторизован -> включение/выключение мода, список всех игроков с модом, поиск,
 *    отправка и принятие заявок в друзья, бинд метки на любую кнопку, стиль/цвет HUD и координаты друзей.
 */
public class GuardPingScreen extends Screen {
    private boolean registerMode = false;
    private String draftLogin = "";
    private String draftPassword = "";
    private String draftConfirm = "";
    private TextFieldWidget loginField;
    private TextFieldWidget passwordField;
    private TextFieldWidget confirmPasswordField;

    private TextFieldWidget searchUserField;
    private boolean waitingForPingBind = false;
    private ButtonWidget rebindButton;

    public GuardPingScreen() {
        super(Text.literal("Guard-Ping-Mod"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        // Верхняя кнопка включения/выключения мода
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Мод: " + (ModConfig.INSTANCE.modEnabled ? "ВКЛ" : "ВЫКЛ"))
                        .formatted(ModConfig.INSTANCE.modEnabled ? Formatting.GREEN : Formatting.RED),
                btn -> {
                    ModConfig.INSTANCE.modEnabled = !ModConfig.INSTANCE.modEnabled;
                    ModConfig.save();
                    this.clearAndInit();
                }).dimensions(cx - 165, 10, 80, 18).build());

        if (!CloudSyncManager.isAuthenticated) {
            initAuthScreen(cx);
        } else {
            initMainScreen(cx);
        }
    }

    private void initAuthScreen(int cx) {
        Text loginTabText = this.registerMode ? Text.literal("Вход").formatted(Formatting.GRAY) : Text.literal("► Вход").formatted(Formatting.AQUA);
        Text regTabText = this.registerMode ? Text.literal("► Регистрация").formatted(Formatting.GREEN) : Text.literal("Регистрация").formatted(Formatting.GRAY);

        this.addDrawableChild(ButtonWidget.builder(loginTabText, btn -> {
            if (this.loginField != null) this.draftLogin = this.loginField.getText();
            if (this.passwordField != null) this.draftPassword = this.passwordField.getText();
            if (this.confirmPasswordField != null) this.draftConfirm = this.confirmPasswordField.getText();
            this.registerMode = false;
            this.clearAndInit();
        }).dimensions(cx - 105, 48, 100, 20).build());

        this.addDrawableChild(ButtonWidget.builder(regTabText, btn -> {
            if (this.loginField != null) this.draftLogin = this.loginField.getText();
            if (this.passwordField != null) this.draftPassword = this.passwordField.getText();
            if (this.confirmPasswordField != null) this.draftConfirm = this.confirmPasswordField.getText();
            this.registerMode = true;
            this.clearAndInit();
        }).dimensions(cx + 5, 48, 100, 20).build());

        this.loginField = new TextFieldWidget(this.textRenderer, cx - 105, 80, 210, 20, Text.literal("Логин"));
        this.loginField.setMaxLength(24);
        this.loginField.setText(this.draftLogin);
        this.loginField.setChangedListener(s -> this.draftLogin = s);
        this.loginField.setPlaceholder(Text.literal("Придумай или введи логин...").formatted(Formatting.GRAY));
        this.addDrawableChild(this.loginField);

        this.passwordField = new TextFieldWidget(this.textRenderer, cx - 105, 108, 210, 20, Text.literal("Пароль"));
        this.passwordField.setMaxLength(32);
        this.passwordField.setText(this.draftPassword);
        this.passwordField.setChangedListener(s -> this.draftPassword = s);
        this.passwordField.setPlaceholder(Text.literal("Пароль...").formatted(Formatting.GRAY));
        this.addDrawableChild(this.passwordField);

        if (this.registerMode) {
            this.confirmPasswordField = new TextFieldWidget(this.textRenderer, cx - 105, 136, 210, 20, Text.literal("Повтор пароля"));
            this.confirmPasswordField.setMaxLength(32);
            this.confirmPasswordField.setText(this.draftConfirm);
            this.confirmPasswordField.setChangedListener(s -> this.draftConfirm = s);
            this.confirmPasswordField.setPlaceholder(Text.literal("Повтори пароль...").formatted(Formatting.GRAY));
            this.addDrawableChild(this.confirmPasswordField);

            this.addDrawableChild(ButtonWidget.builder(Text.literal("Зарегистрироваться").formatted(Formatting.GREEN), btn -> {
                CloudSyncManager.registerAsync(
                        this.loginField.getText().trim(),
                        this.passwordField.getText(),
                        this.confirmPasswordField.getText(),
                        this::clearAndInit
                );
            }).dimensions(cx - 105, 166, 210, 22).build());
        } else {
            this.addDrawableChild(ButtonWidget.builder(Text.literal("Войти в аккаунт").formatted(Formatting.AQUA), btn -> {
                CloudSyncManager.loginAsync(
                        this.loginField.getText().trim(),
                        this.passwordField.getText(),
                        this::clearAndInit
                );
            }).dimensions(cx - 105, 140, 210, 22).build());
        }

        TextFieldWidget dbField = new TextFieldWidget(this.textRenderer, cx - 155, 222, 225, 18, Text.literal("Vercel API URL"));
        dbField.setMaxLength(256);
        dbField.setText(ModConfig.INSTANCE.vercelApiUrl);
        dbField.setPlaceholder(Text.literal("https://твой-проект.vercel.app/api/ping").formatted(Formatting.GRAY));
        this.addDrawableChild(dbField);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Сохранить API"), btn -> {
            ModConfig.INSTANCE.provider = "VERCEL";
            ModConfig.INSTANCE.vercelApiUrl = dbField.getText().trim();
            ModConfig.save();
            CloudSyncManager.authStatusMessage = "§aVercel API сохранён!";
        }).dimensions(cx + 75, 222, 85, 18).build());
    }

    private void initMainScreen(int cx) {
        // Выход из аккаунта
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Выйти"), btn -> {
            CloudSyncManager.logout();
            this.clearAndInit();
        }).dimensions(cx + 105, 10, 60, 18).build());

        // 1. Бинд метки + Подсветка видимых друзей
        this.rebindButton = ButtonWidget.builder(getBindButtonText(), btn -> {
            this.waitingForPingBind = true;
            btn.setMessage(Text.literal("> Нажми ЛЮБУЮ клавишу/кнопку мыши <").formatted(Formatting.YELLOW));
        }).dimensions(cx - 165, 36, 210, 20).build();
        this.addDrawableChild(this.rebindButton);

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Glow: " + (ModConfig.INSTANCE.glowEnabled ? "ВКЛ" : "ВЫКЛ"))
                        .formatted(ModConfig.INSTANCE.glowEnabled ? Formatting.GREEN : Formatting.RED),
                btn -> {
                    ModConfig.INSTANCE.glowEnabled = !ModConfig.INSTANCE.glowEnabled;
                    ModConfig.save();
                    this.clearAndInit();
                }).dimensions(cx + 50, 36, 115, 20).build());

        // 2. Стиль метки + Цвет метки + Коорд. HUD
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Стиль: " + ModConfig.INSTANCE.getStyleName()), btn -> {
            ModConfig.INSTANCE.pingStyleIndex = (ModConfig.INSTANCE.pingStyleIndex + 1) % ModConfig.STYLE_NAMES.length;
            ModConfig.save();
            this.clearAndInit();
        }).dimensions(cx - 165, 60, 105, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Цвет: " + ModConfig.INSTANCE.getColorName()), btn -> {
            ModConfig.INSTANCE.pingColorIndex = (ModConfig.INSTANCE.pingColorIndex + 1) % ModConfig.COLOR_NAMES.length;
            ModConfig.save();
            this.clearAndInit();
        }).dimensions(cx - 55, 60, 105, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Коорд. HUD: " + (ModConfig.INSTANCE.coordsHudEnabled ? "ВКЛ" : "ВЫКЛ")),
                btn -> {
                    ModConfig.INSTANCE.coordsHudEnabled = !ModConfig.INSTANCE.coordsHudEnabled;
                    ModConfig.save();
                    this.clearAndInit();
                }).dimensions(cx + 55, 60, 110, 20).build());

        // 3. Поиск среди тех, кто использует мод
        this.searchUserField = new TextFieldWidget(this.textRenderer, cx - 165, 86, 210, 20, Text.literal("Поиск"));
        this.searchUserField.setMaxLength(24);
        this.searchUserField.setPlaceholder(Text.literal("Фильтр игроков с модом...").formatted(Formatting.GRAY));
        this.searchUserField.setChangedListener(text -> refreshUserButtons());
        this.addDrawableChild(this.searchUserField);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Обновить"), btn -> this.clearAndInit())
                .dimensions(cx + 50, 86, 115, 20).build());

        // 4. Входящие заявки в друзья (левая колонка)
        int rowY = 126;
        List<String> reqs = new ArrayList<>(CloudSyncManager.INCOMING_REQUESTS);
        for (int i = 0; i < Math.min(reqs.size(), 3); i++) {
            String reqLogin = reqs.get(i);
            this.addDrawableChild(ButtonWidget.builder(Text.literal("✓ " + reqLogin).formatted(Formatting.GREEN), btn -> {
                CloudSyncManager.acceptFriendRequest(reqLogin);
                this.clearAndInit();
            }).dimensions(cx - 165, rowY + (i * 22), 115, 19).build());

            this.addDrawableChild(ButtonWidget.builder(Text.literal("✗").formatted(Formatting.RED), btn -> {
                CloudSyncManager.declineFriendRequest(reqLogin);
                this.clearAndInit();
            }).dimensions(cx - 47, rowY + (i * 22), 24, 19).build());
        }

        // 5. Список игроков, у которых установлен мод (правая колонка)
        String filter = this.searchUserField != null ? this.searchUserField.getText().trim().toLowerCase() : "";
        int shown = 0;
        for (AccountProfile p : CloudSyncManager.MOD_USERS.values()) {
            if (shown >= 4) break;
            if (p.login.equalsIgnoreCase(ModConfig.INSTANCE.savedLogin)) continue;
            if (!filter.isEmpty() && !p.login.toLowerCase().contains(filter) && !p.mcNick.toLowerCase().contains(filter)) continue;

            boolean isFriend = ModConfig.INSTANCE.friends.stream().anyMatch(f -> f.equalsIgnoreCase(p.login));
            String dot = p.isOnline() ? "§a● " : "§7● ";
            String btnText = isFriend
                    ? dot + p.login + " §7(Друг)"
                    : dot + "+ " + p.login + " §8(" + p.mcNick + ")";
            this.addDrawableChild(ButtonWidget.builder(Text.literal(btnText), btn -> {
                if (!isFriend) {
                    CloudSyncManager.sendFriendRequest(p.login);
                }
            }).dimensions(cx - 10, rowY + (shown * 22), 175, 19).build());
            shown++;
        }
    }

    private void refreshUserButtons() {
        // Фильтр обновляется при нажатии "Обновить" или перерисовке
    }

    private Text getBindButtonText() {
        String keyName;
        if (ModConfig.INSTANCE.pingKeyIsMouse) {
            keyName = switch (ModConfig.INSTANCE.pingKeyCode) {
                case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> "СКМ (Mouse 3)";
                case GLFW.GLFW_MOUSE_BUTTON_LEFT -> "ЛКМ (Mouse 1)";
                case GLFW.GLFW_MOUSE_BUTTON_RIGHT -> "ПКМ (Mouse 2)";
                default -> "Mouse " + (ModConfig.INSTANCE.pingKeyCode + 1);
            };
        } else {
            keyName = InputUtil.Type.KEYSYM.createFromCode(ModConfig.INSTANCE.pingKeyCode).getLocalizedText().getString();
        }
        return Text.literal("Бинд метки: " + keyName);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.waitingForPingBind) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                ModConfig.INSTANCE.pingKeyIsMouse = false;
                ModConfig.INSTANCE.pingKeyCode = keyCode;
                ModConfig.save();
            }
            this.waitingForPingBind = false;
            this.rebindButton.setMessage(getBindButtonText());
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (this.waitingForPingBind) {
            ModConfig.INSTANCE.pingKeyIsMouse = true;
            ModConfig.INSTANCE.pingKeyCode = button;
            ModConfig.save();
            this.waitingForPingBind = false;
            this.rebindButton.setMessage(getBindButtonText());
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // В MC 1.21.11 super.render() сам применяет размытие фона — renderBackground() вызывать НЕ нужно!
        super.render(context, mouseX, mouseY, delta);

        int cx = this.width / 2;
        context.drawCenteredTextWithShadow(this.textRenderer, "§b§lGuard-Ping-Mod §7(1.21.11)", cx, 14, 0xFFFFFF);

        if (!CloudSyncManager.isAuthenticated) {
            context.drawCenteredTextWithShadow(this.textRenderer, "§7Войди или зарегистрируйся, чтобы не терять друзей", cx, 34, 0xAAAAAA);
            if (!CloudSyncManager.authStatusMessage.isEmpty()) {
                int sw = Math.max(210, this.textRenderer.getWidth(CloudSyncManager.authStatusMessage) + 16);
                context.fill(cx - sw / 2, 194, cx + sw / 2, 210, 0xBB0B0F1A);
                context.drawCenteredTextWithShadow(this.textRenderer, CloudSyncManager.authStatusMessage, cx, 198, 0xFFFFFF);
            }
            return;
        }

        context.drawTextWithShadow(this.textRenderer, "§eЗаявки в друзья:", cx - 165, 113, 0xFFFFFF);
        context.drawTextWithShadow(this.textRenderer, "§aПользователи мода:", cx - 10, 113, 0xFFFFFF);

        int coordsY = 220;
        context.drawTextWithShadow(this.textRenderer, "§bКоординаты друзей (§f" + ModConfig.INSTANCE.savedLogin + "§b):", cx - 165, coordsY, 0xFFFFFF);
        int line = 1;
        for (AccountProfile p : CloudSyncManager.MOD_USERS.values()) {
            if (!ModConfig.INSTANCE.friends.stream().anyMatch(f -> f.equalsIgnoreCase(p.login))) continue;
            if (line > 5) break;
            String distText = "";
            if (this.client != null && this.client.player != null) {
                double dx = p.x - this.client.player.getX();
                double dy = p.y - this.client.player.getY();
                double dz = p.z - this.client.player.getZ();
                distText = String.format(" (%.0f м)", Math.sqrt(dx * dx + dy * dy + dz * dz));
            }
            String status = p.isOnline() ? "§a●" : "§7●";
            String row = String.format("%s §f%s §7(%s): §a%.0f %.0f %.0f§7%s", status, p.login, p.mcNick, p.x, p.y, p.z, distText);
            context.drawTextWithShadow(this.textRenderer, row, cx - 165, coordsY + (line * 12), 0xFFFFFF);
            line++;
        }
        if (line == 1) {
            context.drawTextWithShadow(this.textRenderer, "§7Список друзей пуст — добавь справа из списка!", cx - 165, coordsY + 12, 0xAAAAAA);
        }
    }
}
