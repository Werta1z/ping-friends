package kz.avgar.guardping.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File CONFIG_FILE = FabricLoader.getInstance().getConfigDir().resolve("guardping.json").toFile();

    public static ModConfig INSTANCE = new ModConfig();

    public boolean modEnabled = true;

    // Аккаунт в облачной БД
    public String savedLogin = "";
    public String savedPasswordHash = "";

    // Провайдер: "VERCEL" (через твой Vercel + Neon) или "FIREBASE"
    public String provider = "VERCEL";

    // URL твоего Vercel API (например: https://guard-ping.vercel.app/api/ping)
    public String vercelApiUrl = "";
    public String firebaseDatabaseUrl = "";
    public String neonDataApiUrl = "";

    // Список друзей (по их логину в моде)
    public List<String> friends = new ArrayList<>();

    // Визуальные настройки HUD
    public boolean glowEnabled = false;
    public boolean coordsHudEnabled = true;
    public int pingStyleIndex = 0; // 0: НЕОН, 1: КИБЕР, 2: ТАКТИК, 3: МИНИМАЛ
    public int pingColorIndex = 0; // 0: Бирюзовый, 1: Фиолетовый, 2: Золотой, 3: Красный, 4: Зелёный

    // Бинд метки (по умолчанию СКМ = 2)
    public boolean pingKeyIsMouse = true;
    public int pingKeyCode = GLFW.GLFW_MOUSE_BUTTON_MIDDLE;

    public int pingDurationSeconds = 15;

    public static final String[] STYLE_NAMES = {"НЕОН", "КИБЕР", "ТАКТИК", "МИНИМАЛ"};
    public static final String[] COLOR_NAMES = {"Бирюзовый", "Фиолетовый", "Золотой", "Красный", "Зелёный"};
    public static final int[] COLOR_VALUES = {0xFF00E5FF, 0xFFBB66FF, 0xFFFFCC33, 0xFFFF4455, 0xFF33FF88};

    public int getAccentColor() {
        return COLOR_VALUES[Math.floorMod(pingColorIndex, COLOR_VALUES.length)];
    }

    public String getStyleName() {
        return STYLE_NAMES[Math.floorMod(pingStyleIndex, STYLE_NAMES.length)];
    }

    public String getColorName() {
        return COLOR_NAMES[Math.floorMod(pingColorIndex, COLOR_NAMES.length)];
    }

    public static void load() {
        if (CONFIG_FILE.exists()) {
            try (FileReader reader = new FileReader(CONFIG_FILE, StandardCharsets.UTF_8)) {
                ModConfig loaded = GSON.fromJson(reader, ModConfig.class);
                if (loaded != null) {
                    INSTANCE = loaded;
                    if (INSTANCE.friends == null) INSTANCE.friends = new ArrayList<>();
                    if (INSTANCE.neonDataApiUrl == null || INSTANCE.neonDataApiUrl.isBlank()) {
                        INSTANCE.neonDataApiUrl = "https://ep-crimson-water-ba17lj8s.apirest.c-8.eu-central-1.aws.neon.tech/neondb/rest/v1";
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            save();
        }
    }

    public static void save() {
        try (FileWriter writer = new FileWriter(CONFIG_FILE, StandardCharsets.UTF_8)) {
            GSON.toJson(INSTANCE, writer);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
