package kz.avgar.guardping;

import com.mojang.brigadier.arguments.StringArgumentType;
import kz.avgar.guardping.cloud.CloudSyncManager;
import kz.avgar.guardping.config.ModConfig;
import kz.avgar.guardping.gui.GuardPingScreen;
import kz.avgar.guardping.model.AccountProfile;
import kz.avgar.guardping.render.PingHudOverlay;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class GuardPingClient implements ClientModInitializer {
    public static KeyBinding openMenuKey;
    private static boolean pingKeyWasDown = false;

    @Override
    public void onInitializeClient() {
        ModConfig.load();
        CloudSyncManager.start();

        // В MC 1.21.11 KeyBinding принимает KeyBinding.Category.MISC
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.guardping.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_PAGE_UP,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                client.setScreen(new GuardPingScreen());
            }

            // Отслеживаем ЛЮБУЮ клавишу клавиатуры или кнопку мыши без риска краша миксинов
            if (client.currentScreen == null && client.player != null && ModConfig.INSTANCE.modEnabled && CloudSyncManager.isAuthenticated) {
                long handle = client.getWindow().getHandle();
                boolean isDown = ModConfig.INSTANCE.pingKeyIsMouse
                        ? GLFW.glfwGetMouseButton(handle, ModConfig.INSTANCE.pingKeyCode) == GLFW.GLFW_PRESS
                        : GLFW.glfwGetKey(handle, ModConfig.INSTANCE.pingKeyCode) == GLFW.GLFW_PRESS;

                if (isDown && !pingKeyWasDown) {
                    triggerRaycastPing(client);
                }
                pingKeyWasDown = isDown;
            } else {
                pingKeyWasDown = false;
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            PingHudOverlay.render(drawContext);
        });

        registerCommands();
    }

    public static void triggerRaycastPing(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        Entity cameraEntity = client.getCameraEntity() != null ? client.getCameraEntity() : client.player;
        HitResult hit = cameraEntity.raycast(250.0, 1.0f, false);
        Vec3d targetPos = hit.getPos();
        String dim = client.world.getRegistryKey().getValue().toString();

        CloudSyncManager.publishPing(targetPos.x, targetPos.y, targetPos.z, dim);
        client.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), 0.7f, 1.6f);
    }

    private void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("kor")
                    .executes(ctx -> {
                        printAllFriendCoords();
                        return 1;
                    })
                    .then(ClientCommandManager.literal("glow")
                            .executes(ctx -> {
                                toggleFriendGlow();
                                return 1;
                            }))
                    .then(ClientCommandManager.argument("player", StringArgumentType.word())
                            .executes(ctx -> {
                                String target = StringArgumentType.getString(ctx, "player");
                                if ("glow".equalsIgnoreCase(target) || "глов".equalsIgnoreCase(target)) {
                                    toggleFriendGlow();
                                } else {
                                    printFriendCoords(target);
                                }
                                return 1;
                            }))
            );

            dispatcher.register(ClientCommandManager.literal("кор")
                    .executes(ctx -> {
                        printAllFriendCoords();
                        return 1;
                    })
                    .then(ClientCommandManager.literal("глов")
                            .executes(ctx -> {
                                toggleFriendGlow();
                                return 1;
                            }))
                    .then(ClientCommandManager.argument("player", StringArgumentType.word())
                            .executes(ctx -> {
                                String target = StringArgumentType.getString(ctx, "player");
                                if ("glow".equalsIgnoreCase(target) || "глов".equalsIgnoreCase(target)) {
                                    toggleFriendGlow();
                                } else {
                                    printFriendCoords(target);
                                }
                                return 1;
                            }))
            );
        });
    }

    private void toggleFriendGlow() {
        ModConfig.INSTANCE.glowEnabled = !ModConfig.INSTANCE.glowEnabled;
        ModConfig.save();
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            String state = ModConfig.INSTANCE.glowEnabled ? "ВКЛЮЧЕНА (только видимые)" : "ВЫКЛЮЧЕНА";
            Formatting color = ModConfig.INSTANCE.glowEnabled ? Formatting.GREEN : Formatting.RED;
            client.player.sendMessage(Text.literal("[Guard-Ping] ").formatted(Formatting.AQUA)
                    .append(Text.literal("Подсветка друзей: " + state).formatted(color)), false);
        }
    }

    private void printAllFriendCoords() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        boolean found = false;
        for (AccountProfile p : CloudSyncManager.MOD_USERS.values()) {
            if (ModConfig.INSTANCE.friends.stream().anyMatch(f -> f.equalsIgnoreCase(p.login))) {
                sendCoordLine(p);
                found = true;
            }
        }
        if (!found) {
            client.player.sendMessage(Text.literal("[Guard-Ping] ").formatted(Formatting.AQUA)
                    .append(Text.literal("Нет друзей в списке. Открой меню на Page Up!").formatted(Formatting.YELLOW)), false);
        }
    }

    private void printFriendCoords(String targetName) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        for (AccountProfile p : CloudSyncManager.MOD_USERS.values()) {
            if ((p.login.equalsIgnoreCase(targetName) || p.mcNick.equalsIgnoreCase(targetName))
                    && ModConfig.INSTANCE.friends.stream().anyMatch(f -> f.equalsIgnoreCase(p.login))) {
                sendCoordLine(p);
                return;
            }
        }
        client.player.sendMessage(Text.literal("[Guard-Ping] ").formatted(Formatting.AQUA)
                .append(Text.literal("Друг " + targetName + " не найден.").formatted(Formatting.RED)), false);
    }

    private void sendCoordLine(AccountProfile p) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        double dx = p.x - client.player.getX();
        double dy = p.y - client.player.getY();
        double dz = p.z - client.player.getZ();
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        String msg = String.format("§b[%s | %s] §fX: §a%.0f §fY: §a%.0f §fZ: §a%.0f §7(%.1f м)",
                p.login, p.mcNick, p.x, p.y, p.z, dist);
        client.player.sendMessage(Text.literal(msg), false);
    }
}
