package kz.avgar.guardping.render;

import kz.avgar.guardping.cloud.CloudSyncManager;
import kz.avgar.guardping.config.ModConfig;
import kz.avgar.guardping.model.AccountProfile;
import kz.avgar.guardping.model.PingMarker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

/**
 * Плавная отрисовка меток с субпиксельным сглаживанием через Matrix3x2fStack (MC 1.21.11),
 * выбором 4 стилей (НЕОН, КИБЕР, ТАКТИК, МИНИМАЛ), виджетом координат друзей и тостом входящих заявок.
 */
public class PingHudOverlay {

    private static class SmoothPos {
        float x, y;
        boolean initialized = false;
    }

    private static final Map<String, SmoothPos> SMOOTH_CACHE = new HashMap<>();
    private static long lastFrameNanos = System.nanoTime();

    public static void render(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.options.hudHidden) return;
        if (!ModConfig.INSTANCE.modEnabled || !CloudSyncManager.isAuthenticated) return;

        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastFrameNanos) / 1_000_000_000f);
        lastFrameNanos = now;
        float smoothFactor = 1.0f - (float) Math.exp(-22.0 * dt);

        TextRenderer tr = client.textRenderer;
        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();

        // 1. Тост-уведомление о входящей заявке в друзья (правый верхний угол)
        if (System.currentTimeMillis() < CloudSyncManager.latestToastUntil && !CloudSyncManager.latestToastText.isEmpty()) {
            String toast = CloudSyncManager.latestToastText;
            int tw = tr.getWidth(toast) + 16;
            int tx = screenW - tw - 10;
            int ty = 10;
            drawStyledPanel(context, tx, ty, tw, 22, 0xFF33FF88);
            context.drawTextWithShadow(tr, toast, tx + 8, ty + 7, 0xFFFFFFFF);
        }

        // 2. Виджет координат друзей (левый верхний угол)
        if (ModConfig.INSTANCE.coordsHudEnabled) {
            renderFriendsCoordsHud(context, client, tr);
        }

        // 3. Плавные метки (Pings)
        if (CloudSyncManager.ACTIVE_PINGS.isEmpty()) return;

        String currentDim = client.world.getRegistryKey().getValue().toString();
        Camera camera = client.gameRenderer.getCamera();
        Vec3d camPos = camera.getPos();
        float camYaw = MathHelper.wrapDegrees(camera.getYaw());
        float camPitch = camera.getPitch();
        double fov = client.options.getFov().getValue();

        int accent = ModConfig.INSTANCE.getAccentColor();
        int style = Math.floorMod(ModConfig.INSTANCE.pingStyleIndex, 4);
        float pulse = 0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 220.0);

        for (PingMarker ping : CloudSyncManager.ACTIVE_PINGS) {
            if (!currentDim.equals(ping.dimension)) continue;

            double dx = ping.x - camPos.x;
            double dy = (ping.y + 0.5) - camPos.y;
            double dz = ping.z - camPos.z;
            double distanceMeters = Math.sqrt(dx * dx + dy * dy + dz * dz);

            double angleToTarget = Math.toDegrees(Math.atan2(-dx, dz));
            double relYaw = MathHelper.wrapDegrees(angleToTarget - camYaw);

            double horizontalDist = Math.sqrt(dx * dx + dz * dz);
            double pitchToTarget = -Math.toDegrees(Math.atan2(dy, horizontalDist));
            double relPitch = pitchToTarget - camPitch;

            double halfFovX = (fov * ((double) screenW / screenH)) / 2.0;
            double halfFovY = fov / 2.0;

            float targetX = (float) (screenW / 2.0 + (relYaw / halfFovX) * (screenW / 2.0));
            float targetY = (float) (screenH / 2.0 + (relPitch / halfFovY) * (screenH / 2.0));

            int margin = 34;
            boolean offScreen = Math.abs(relYaw) > halfFovX || Math.abs(relPitch) > halfFovY;
            targetX = MathHelper.clamp(targetX, margin, screenW - margin);
            targetY = MathHelper.clamp(targetY, margin, screenH - margin);

            SmoothPos sp = SMOOTH_CACHE.computeIfAbsent(ping.id, k -> new SmoothPos());
            if (!sp.initialized) {
                sp.x = targetX;
                sp.y = targetY;
                sp.initialized = true;
            } else {
                sp.x += (targetX - sp.x) * smoothFactor;
                sp.y += (targetY - sp.y) * smoothFactor;
            }

            // Субпиксельная плавная трансляция через Matrix3x2fStack (без рывков по пикселям!)
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(sp.x, sp.y);

            String dir = getCardinalDirection(angleToTarget);
            String title = ping.sender + " [" + dir + "]";
            String dist = String.format("%.1f м", distanceMeters);
            float lifeProgress = ping.getProgress(ModConfig.INSTANCE.pingDurationSeconds);
            int color = offScreen ? 0xFFFFAA00 : accent;

            if (style == 0) {
                // НЕОН: стеклянная карточка + рамка + пульсирующий ромб + полоска времени
                int w = Math.max(tr.getWidth(title), tr.getWidth(dist)) + 14;
                int bx = -w / 2;
                int by = -32;
                drawStyledPanel(context, bx, by, w, 24, color);
                int barW = (int) ((w - 4) * lifeProgress);
                context.fill(bx + 2, by + 21, bx + 2 + barW, by + 22, color);

                context.drawCenteredTextWithShadow(tr, title, 0, by + 3, color);
                context.drawCenteredTextWithShadow(tr, dist, 0, by + 12, 0xFFFFFFFF);

                int r = pulse > 0.5f ? 4 : 3;
                context.fill(-r, -r, r, r, color);
                context.fill(-1, -1, 1, 1, 0xFFFFFFFF);
            } else if (style == 1) {
                // КИБЕР: угловые тактические скобки
                int w = Math.max(tr.getWidth(title), tr.getWidth(dist)) + 14;
                int bx = -w / 2;
                int by = -30;
                context.fill(bx, by, bx + w, by + 21, 0x88090D16);
                // Уголки
                context.fill(bx, by, bx + 5, by + 1, color);
                context.fill(bx, by, bx + 1, by + 5, color);
                context.fill(bx + w - 5, by, bx + w, by + 1, color);
                context.fill(bx + w - 1, by, bx + w, by + 5, color);

                context.drawCenteredTextWithShadow(tr, title, 0, by + 2, 0xFFFFFFFF);
                context.drawCenteredTextWithShadow(tr, dist, 0, by + 11, color);
                context.fill(-2, -2, 2, 2, color);
            } else if (style == 2) {
                // ТАКТИК: компактный маркер-прицел
                context.fill(-5, -1, 5, 1, color);
                context.fill(-1, -5, 1, 5, color);
                context.drawCenteredTextWithShadow(tr, title + " · " + dist, 0, -16, color);
            } else {
                // МИНИМАЛ: только аккуратная точка и текст
                context.fill(-2, -2, 2, 2, color);
                context.drawCenteredTextWithShadow(tr, ping.sender + " (" + dist + ")", 0, -14, 0xFFFFFFFF);
            }

            context.getMatrices().popMatrix();
        }
    }

    private static void renderFriendsCoordsHud(DrawContext context, MinecraftClient client, TextRenderer tr) {
        int y = 8;
        int shown = 0;
        for (AccountProfile p : CloudSyncManager.MOD_USERS.values()) {
            if (shown >= 5) break;
            if (!ModConfig.INSTANCE.friends.stream().anyMatch(f -> f.equalsIgnoreCase(p.login))) continue;
            if (!p.isOnline()) continue;

            double dx = p.x - client.player.getX();
            double dy = p.y - client.player.getY();
            double dz = p.z - client.player.getZ();
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

            String line = String.format("§b%s §7(§f%s§7): §a%.0f %.0f %.0f §7[%.0fм]", p.login, p.mcNick, p.x, p.y, p.z, dist);
            int w = tr.getWidth(line) + 10;
            context.fill(8, y, 8 + w, y + 12, 0x880B0F1A);
            context.fill(8, y, 10, y + 12, ModConfig.INSTANCE.getAccentColor());
            context.drawTextWithShadow(tr, line, 13, y + 2, 0xFFFFFFFF);
            y += 14;
            shown++;
        }
    }

    private static void drawStyledPanel(DrawContext ctx, int x, int y, int w, int h, int borderColor) {
        ctx.fill(x, y, x + w, y + h, 0xB00B0F1A);
        ctx.drawHorizontalLine(x, x + w - 1, y, borderColor);
        ctx.drawHorizontalLine(x, x + w - 1, y + h - 1, borderColor);
        ctx.drawVerticalLine(x, y, y + h - 1, borderColor);
        ctx.drawVerticalLine(x + w - 1, y, y + h - 1, borderColor);
    }

    public static String getCardinalDirection(double yawDegrees) {
        double deg = (yawDegrees % 360.0 + 360.0) % 360.0;
        if (deg >= 337.5 || deg < 22.5) return "Ю";
        if (deg < 67.5) return "ЮЗ";
        if (deg < 112.5) return "З";
        if (deg < 157.5) return "СЗ";
        if (deg < 202.5) return "С";
        if (deg < 247.5) return "СВ";
        if (deg < 292.5) return "В";
        return "ЮВ";
    }
}
