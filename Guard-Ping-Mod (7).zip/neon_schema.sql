-- SQL-скрипт для Guard-Ping-Mod (Neon PostgreSQL + Neon Data API)
-- Открой SQL Editor в Neon Console и выполни этот скрипт один раз.

CREATE TABLE IF NOT EXISTS public.mod_accounts (
    login TEXT PRIMARY KEY,
    password_hash TEXT NOT NULL,
    mc_nick TEXT DEFAULT '',
    x DOUBLE PRECISION DEFAULT 0,
    y DOUBLE PRECISION DEFAULT 0,
    z DOUBLE PRECISION DEFAULT 0,
    dimension TEXT DEFAULT 'minecraft:overworld',
    friends JSONB DEFAULT '[]'::jsonb,
    requests JSONB DEFAULT '[]'::jsonb,
    updated_at BIGINT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS public.mod_pings (
    id TEXT PRIMARY KEY,
    sender TEXT NOT NULL,
    x DOUBLE PRECISION NOT NULL,
    y DOUBLE PRECISION NOT NULL,
    z DOUBLE PRECISION NOT NULL,
    dimension TEXT DEFAULT 'minecraft:overworld',
    created_at BIGINT NOT NULL
);

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anonymous') THEN
        CREATE ROLE anonymous NOLOGIN;
    END IF;
END
$$;

GRANT USAGE ON SCHEMA public TO anonymous;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.mod_accounts TO anonymous;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.mod_pings TO anonymous;

ALTER TABLE public.mod_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mod_pings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow anonymous on mod_accounts" ON public.mod_accounts;
CREATE POLICY "Allow anonymous on mod_accounts"
ON public.mod_accounts FOR ALL TO anonymous USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow anonymous on mod_pings" ON public.mod_pings;
CREATE POLICY "Allow anonymous on mod_pings"
ON public.mod_pings FOR ALL TO anonymous USING (true) WITH CHECK (true);
